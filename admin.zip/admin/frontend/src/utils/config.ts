export const baseURL: string = "https://doctornode.codderlab.com/";
export const key: string = "JIICGbfFkpwq01wQOfDNGEaKAdqGjJDC";
export const projectName: string = "Doctor";
